from distutils.core import setup

setup(
    name='adserv',
    version='0.2.1',
    packages=['adflow','tests'],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
)
